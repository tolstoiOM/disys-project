package at.fhtechnikum.disys4_second;

import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Repository
public class MeasurementRepository {
    private final List<Measurement> measurements;

    public MeasurementRepository() {
        this.measurements = new ArrayList<>();
        // Beispiel-Daten hinzufügen
        for (int i = 0; i < 24; i++) {
            measurements.add(new Measurement(LocalDateTime.now().minusHours(i), Math.random() * 10));
        }
    }

    public List<Measurement> findAll() {
        return new ArrayList<>(measurements);
    }

    public List<Measurement> findByHour(LocalDateTime hour) {
        List<Measurement> result = new ArrayList<>();
        for (Measurement measurement : measurements) {
            if (measurement.getTimestamp().getHour() == hour.getHour() &&
                    measurement.getTimestamp().toLocalDate().equals(hour.toLocalDate())) {
                result.add(measurement);
            }
        }
        return result;
    }
}