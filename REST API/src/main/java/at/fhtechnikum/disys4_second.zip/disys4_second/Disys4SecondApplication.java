package at.fhtechnikum.disys4_second;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Disys4SecondApplication {

    public static void main(String[] args) {
        SpringApplication.run(Disys4SecondApplication.class, args);
    }

}
