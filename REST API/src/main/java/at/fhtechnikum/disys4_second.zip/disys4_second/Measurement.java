package at.fhtechnikum.disys4_second;

import java.time.LocalDateTime;

public class Measurement {
    private LocalDateTime timestamp;
    private double consumption; // Stromverbrauch in kWh

    public Measurement(LocalDateTime timestamp, double consumption) {
        this.timestamp = timestamp;
        this.consumption = consumption;
    }

    public LocalDateTime getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(LocalDateTime timestamp) {
        this.timestamp = timestamp;
    }

    public double getConsumption() {
        return consumption;
    }

    public void setConsumption(double consumption) {
        this.consumption = consumption;
    }
}