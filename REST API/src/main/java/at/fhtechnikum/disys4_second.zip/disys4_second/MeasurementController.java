package at.fhtechnikum.disys4_second;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.List;

@RestController
@RequestMapping("/measurements")
public class MeasurementController {

    private final MeasurementRepository measurementRepository;

    @Autowired
    public MeasurementController(MeasurementRepository measurementRepository) {
        this.measurementRepository = measurementRepository;
    }

    @GetMapping("/current-hour")
    public List<Measurement> getCurrentHourData() {
        LocalDateTime now = LocalDateTime.now();
        return measurementRepository.findByHour(now);
    }

    @GetMapping("/historic")
    public List<Measurement> getHistoricData(@RequestParam("hour") int hour, @RequestParam("date") String date) {
        LocalDateTime requestedTime = LocalDateTime.parse(date + "T" + String.format("%02d", hour) + ":00:00");
        return measurementRepository.findByHour(requestedTime);
    }
}